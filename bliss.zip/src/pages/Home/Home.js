import { Box } from "@mui/material";
import React from "react";


const Home = () => {


  return (
    <Box mt={"50px"}>
      Home
    </Box>
  );
};

export default Home;
